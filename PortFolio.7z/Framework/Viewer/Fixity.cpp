#include "Framework.h"
#include "Fixity.h"

Fixity::Fixity()
{
	Rotation();
	Move();
}

Fixity::~Fixity()
{

}

void Fixity::Update()
{

}
