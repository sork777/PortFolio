#include "Framework.h"
#include "AnimationNotify.h"



AnimationNotify::AnimationNotify()
{
}


AnimationNotify::~AnimationNotify()
{
}
